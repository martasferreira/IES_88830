package ies.moviequotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviequotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
