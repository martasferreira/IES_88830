package ies.moviequotes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviequotesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviequotesApplication.class, args);
	}

}
