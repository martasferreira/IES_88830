package ies.multilayerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultilayerappApplicationTests {

	@Test
	void contextLoads() {
	}

}
